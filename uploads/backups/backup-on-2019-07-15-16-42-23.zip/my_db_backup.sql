#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `firstname` varchar(256) DEFAULT NULL,
  `lastname` varchar(256) DEFAULT NULL,
  `image` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `admin` (`admin_id`, `username`, `password`, `firstname`, `lastname`, `image`) VALUES (2, 'admin', '21232f297a57a5a743894a0e4a801fc3', '3097612d4b7d06b6746cc668dc100210ffc4ec316f36f73bb83874b81a892e19158f5f78edb57e3487d48b7b01b1c620f6ce0bf9508325c52e924f26ba5fb347Y9foZuUxGwXXzHbP2TiVRd4lDSNbKwXwM/IweAqGitQ=', '3097612d4b7d06b6746cc668dc100210ffc4ec316f36f73bb83874b81a892e19158f5f78edb57e3487d48b7b01b1c620f6ce0bf9508325c52e924f26ba5fb347Y9foZuUxGwXXzHbP2TiVRd4lDSNbKwXwM/IweAqGitQ=', 'flowers3.jpg');


#
# TABLE STRUCTURE FOR: appointment
#

DROP TABLE IF EXISTS `appointment`;

CREATE TABLE `appointment` (
  `app_id` int(11) NOT NULL AUTO_INCREMENT,
  `sdate` date NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `description` text,
  `ptime` time NOT NULL,
  `display` varchar(10) NOT NULL,
  PRIMARY KEY (`app_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (1, '2121-12-13', 1, 1, 'undefined', '00:12:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (2, '2121-12-13', 1, 1, 'undefined', '00:12:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (3, '0000-00-00', 3, 1, 'undefined', '00:00:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (4, '0000-00-00', 1, 1, '', '00:00:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (5, '0000-00-00', 1, 1, 'dfadsf', '00:00:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (9, '2019-07-16', 3, 1, '', '00:00:00', 'yes');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (10, '2019-07-02', 1, 1, 'let\'s see', '12:32:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (11, '2212-12-21', 4, 1, 'sfsadfa12', '00:12:00', 'yes');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (12, '0001-07-25', 1, 1, 'my appointment', '00:12:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (13, '1321-02-13', 1, 1, 'some mess', '00:13:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (14, '0031-02-06', 1, 1, 'some appointment', '02:11:00', 'no');


#
# TABLE STRUCTURE FOR: backups
#

DROP TABLE IF EXISTS `backups`;

CREATE TABLE `backups` (
  `backup_id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_date` date DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `user_type` varchar(16) NOT NULL,
  `backup_address` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`backup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: diagnosis
#

DROP TABLE IF EXISTS `diagnosis`;

CREATE TABLE `diagnosis` (
  `diagnosis_id` int(11) NOT NULL AUTO_INCREMENT,
  `diagnosis_file` varchar(256) DEFAULT NULL,
  `appointment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`diagnosis_id`),
  KEY `appointment_id` (`appointment_id`),
  CONSTRAINT `diagnosis_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (4, '2019-07-08-07-07-00diagnosisnew.txt', 4);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (11, '2019-07-12-09-11-26diagnosis.txt', 5);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (13, '2019-07-09-01-43-19diagnosis.txt', 2);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (14, '2019-07-09-01-48-37diagnosis.txt', 1);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (15, '2019-07-09-06-23-42diagnosis.txt', 3);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (16, '2019-07-11-11-32-51diagnosis.txt', 10);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (17, '2019-07-11-11-39-02diagnosis.txt', 10);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (18, '2019-07-11-11-39-18diagnosis.txt', 10);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (19, '2019-07-12-04-22-32diagnosis.txt', 1);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (20, '2019-07-12-04-23-23diagnosis.txt', 1);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (21, '2019-07-12-04-30-04diagnosis.txt', 1);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (22, '2019-07-12-08-12-51diagnosis.txt', 5);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (23, '2019-07-12-08-59-58diagnosis.txt', 5);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (24, '2019-07-13-07-03-20diagnosis.txt', 13);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (25, '2019-07-13-08-48-20diagnosis.txt', 12);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (26, '2019-07-13-09-34-22diagnosis.txt', 14);


#
# TABLE STRUCTURE FOR: doctor
#

DROP TABLE IF EXISTS `doctor`;

CREATE TABLE `doctor` (
  `doctor_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(256) DEFAULT NULL,
  `lastname` varchar(256) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `city` varchar(32) DEFAULT NULL,
  `street` varchar(32) DEFAULT NULL,
  `postCode` varchar(256) DEFAULT NULL,
  `email` varchar(32) DEFAULT NULL,
  `phoneNo` varchar(32) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `image` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `doctor` (`doctor_id`, `firstname`, `lastname`, `dob`, `city`, `street`, `postCode`, `email`, `phoneNo`, `username`, `password`, `image`) VALUES (1, '3660a0ff490b6293fa5266b6f4d56eb7aea8f470f0ed82ebf3e2b20a39feb14507657fb74e94c43c5e699a7eecd98d7431c6fe27276a5eb7bffc404c02d35d62VQill0tkZbRkn4aqkjcmB7MJAy1/mABpS8nZe6vMWIw=', '5246dd4097f6b0ef002c47674b3aeb361ce81945b10f425ff38e79cbe4688284f70c2896588f5046f15e1ce1435e670a4c3cba6907bcc494677581a995108996EXGpydvGTZd2MJFv3EmdioIb4YWKcMCgQA+rbcKIL/k=', '2019-07-02', 'herat', 'herat', '082b9d3216f1b699c1fbb794e04abb9a74af454a4f5234c405a41513b5f713e3d04ddcc4c31f7fb1c3e33a96b70ad326d3e7a5831dcc12d38f9d47ed3c5c8b874w7sTCN3uAbkqIj9XNImq8N8FMb3j3vWBqiY9hzLKME=', 'heratedited@gm.com', 'herat', 'Safiullah ', 'd41d8cd98f00b204e9800998ecf8427e', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');
INSERT INTO `doctor` (`doctor_id`, `firstname`, `lastname`, `dob`, `city`, `street`, `postCode`, `email`, `phoneNo`, `username`, `password`, `image`) VALUES (3, '3097612d4b7d06b6746cc668dc100210ffc4ec316f36f73bb83874b81a892e19158f5f78edb57e3487d48b7b01b1c620f6ce0bf9508325c52e924f26ba5fb347Y9foZuUxGwXXzHbP2TiVRd4lDSNbKwXwM/IweAqGitQ=', '3097612d4b7d06b6746cc668dc100210ffc4ec316f36f73bb83874b81a892e19158f5f78edb57e3487d48b7b01b1c620f6ce0bf9508325c52e924f26ba5fb347Y9foZuUxGwXXzHbP2TiVRd4lDSNbKwXwM/IweAqGitQ=', '0000-00-00', 'dsaf', 'dsafa', 'dsafa', 's@g.com', 'sdfa', 'sd', '21232f297a57a5a743894a0e4a801fc3', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');
INSERT INTO `doctor` (`doctor_id`, `firstname`, `lastname`, `dob`, `city`, `street`, `postCode`, `email`, `phoneNo`, `username`, `password`, `image`) VALUES (4, '3097612d4b7d06b6746cc668dc100210ffc4ec316f36f73bb83874b81a892e19158f5f78edb57e3487d48b7b01b1c620f6ce0bf9508325c52e924f26ba5fb347Y9foZuUxGwXXzHbP2TiVRd4lDSNbKwXwM/IweAqGitQ=', '3097612d4b7d06b6746cc668dc100210ffc4ec316f36f73bb83874b81a892e19158f5f78edb57e3487d48b7b01b1c620f6ce0bf9508325c52e924f26ba5fb347Y9foZuUxGwXXzHbP2TiVRd4lDSNbKwXwM/IweAqGitQ=', '1122-02-12', 'fdas', 'dasf', 'dsfsad', 's@g.com', 'dsfadfa', 'sfs', '21232f297a57a5a743894a0e4a801fc3', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');


#
# TABLE STRUCTURE FOR: patient
#

DROP TABLE IF EXISTS `patient`;

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(256) DEFAULT NULL,
  `lastname` varchar(256) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `job` varchar(32) DEFAULT NULL,
  `city` varchar(32) DEFAULT NULL,
  `street` varchar(32) DEFAULT NULL,
  `postCode` varchar(256) DEFAULT NULL,
  `email` varchar(32) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `phoneNo` varchar(32) DEFAULT NULL,
  `image` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (1, '3097612d4b7d06b6746cc668dc100210ffc4ec316f36f73bb83874b81a892e19158f5f78edb57e3487d48b7b01b1c620f6ce0bf9508325c52e924f26ba5fb347Y9foZuUxGwXXzHbP2TiVRd4lDSNbKwXwM/IweAqGitQ=', '98703af17fa0b5724e6502dbc65bcec8dcac3006cfce35b8af059abd00a27e8d142b98a39290220f721df8b53c007d16a6397e8f7ec2cdcff49dd041933fb195v0ExNf+BquN5hRIhER7zlqTfuZ6++htPDDj4naJZVYM=', '2019-07-15', 'dfa', 'Herat', 'lkdjaslkfj', 'febaeaf2a48d0e6ef22a61b685d4aeda8e6d61b9f4a52d6eee9e35a50ad0e1dfa33e0b6f1bc32a1e3dfbf94004bf02c228bea0994bee248820bb6d89f785891cfGAlP4nqA7Odw+DjoEpvH0NooerTbEifTEMTDPQGp78=', 's@g.com', 'safi', '21232f297a57a5a743894a0e4a801fc3', '0734987432', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');
INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (2, '39018d06cff5ff3bb4392ed55b2de3d2101c1f612034dd1d5957f65a426f7eec741a09800a8fd309f058d7e540128f3a6c9e82e46ab77d57b839c8a7e8972877fcEpPBTGmddbkg8pjuG3FzAO3ussiiVuy9txR2noPcI=', '4dbe690c9965b1f857fac1e13cf26df2c52b72464b49797df03af3e8777afca035e93bc390ec5425cfba8f95a97013c95ffc407a40cdec54078ba1ce2e2af525A8RxmZJotYctDe+mKIqOAvZ/0JrIVzYRCgQt1hkwXik=', '2222-01-29', 'lkfdjal', 'dkfjsl', 'lkdjfal', 'efe8ed922fb2c43f2fde79d552feda30ed9cd9e905609832513fd23d81f8f8dc34351c93efc658862e903abf4220f27f3e58997cbff64116c02e6a5211a8eed4cg/gQbqcNAourycTPsZgj94J7keMyihPyo1kLAsLbTs=', 'a@g.com', 'dfasfd', 'sdjf', '231321', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');
INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (3, '39018d06cff5ff3bb4392ed55b2de3d2101c1f612034dd1d5957f65a426f7eec741a09800a8fd309f058d7e540128f3a6c9e82e46ab77d57b839c8a7e8972877fcEpPBTGmddbkg8pjuG3FzAO3ussiiVuy9txR2noPcI=', '4dbe690c9965b1f857fac1e13cf26df2c52b72464b49797df03af3e8777afca035e93bc390ec5425cfba8f95a97013c95ffc407a40cdec54078ba1ce2e2af525A8RxmZJotYctDe+mKIqOAvZ/0JrIVzYRCgQt1hkwXik=', '2019-07-04', 'dsfs', 'dsfa', 'dsfsd', 'efe8ed922fb2c43f2fde79d552feda30ed9cd9e905609832513fd23d81f8f8dc34351c93efc658862e903abf4220f27f3e58997cbff64116c02e6a5211a8eed4cg/gQbqcNAourycTPsZgj94J7keMyihPyo1kLAsLbTs=', 'someemail@gmail.com', 'ahmet', 'mehmet', 'dsfsdafs', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');
INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (4, '39018d06cff5ff3bb4392ed55b2de3d2101c1f612034dd1d5957f65a426f7eec741a09800a8fd309f058d7e540128f3a6c9e82e46ab77d57b839c8a7e8972877fcEpPBTGmddbkg8pjuG3FzAO3ussiiVuy9txR2noPcI=', '4dbe690c9965b1f857fac1e13cf26df2c52b72464b49797df03af3e8777afca035e93bc390ec5425cfba8f95a97013c95ffc407a40cdec54078ba1ce2e2af525A8RxmZJotYctDe+mKIqOAvZ/0JrIVzYRCgQt1hkwXik=', '0212-12-10', 'dsfas', 'dsf', 'sdfds', 'efe8ed922fb2c43f2fde79d552feda30ed9cd9e905609832513fd23d81f8f8dc34351c93efc658862e903abf4220f27f3e58997cbff64116c02e6a5211a8eed4cg/gQbqcNAourycTPsZgj94J7keMyihPyo1kLAsLbTs=', 'someemail@gmail.com', 'username', '$2y$10$yvEkSlsFhlB9lU8H5ZbP3OWey', 'sdfsdf', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');
INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (5, '39018d06cff5ff3bb4392ed55b2de3d2101c1f612034dd1d5957f65a426f7eec741a09800a8fd309f058d7e540128f3a6c9e82e46ab77d57b839c8a7e8972877fcEpPBTGmddbkg8pjuG3FzAO3ussiiVuy9txR2noPcI=', '4dbe690c9965b1f857fac1e13cf26df2c52b72464b49797df03af3e8777afca035e93bc390ec5425cfba8f95a97013c95ffc407a40cdec54078ba1ce2e2af525A8RxmZJotYctDe+mKIqOAvZ/0JrIVzYRCgQt1hkwXik=', '1311-02-17', 'dsf', 'dsf', 'dfs', 'efe8ed922fb2c43f2fde79d552feda30ed9cd9e905609832513fd23d81f8f8dc34351c93efc658862e903abf4220f27f3e58997cbff64116c02e6a5211a8eed4cg/gQbqcNAourycTPsZgj94J7keMyihPyo1kLAsLbTs=', 'someemail@gmail.com', 'ahmet', '$2y$10$Tvcjv5nISrtJctGjo/2Gr.pcC', 'dfs', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');
INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (6, '39018d06cff5ff3bb4392ed55b2de3d2101c1f612034dd1d5957f65a426f7eec741a09800a8fd309f058d7e540128f3a6c9e82e46ab77d57b839c8a7e8972877fcEpPBTGmddbkg8pjuG3FzAO3ussiiVuy9txR2noPcI=', '4dbe690c9965b1f857fac1e13cf26df2c52b72464b49797df03af3e8777afca035e93bc390ec5425cfba8f95a97013c95ffc407a40cdec54078ba1ce2e2af525A8RxmZJotYctDe+mKIqOAvZ/0JrIVzYRCgQt1hkwXik=', '0212-12-23', 'dsfa', 'dsf', 'dsfa', 'efe8ed922fb2c43f2fde79d552feda30ed9cd9e905609832513fd23d81f8f8dc34351c93efc658862e903abf4220f27f3e58997cbff64116c02e6a5211a8eed4cg/gQbqcNAourycTPsZgj94J7keMyihPyo1kLAsLbTs=', 'someemail@gmail.com', 'gholam', '$2y$10$1VKlF5MLfcYmGsgs9C9JcuMIa', 'dfs', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');
INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (7, '39018d06cff5ff3bb4392ed55b2de3d2101c1f612034dd1d5957f65a426f7eec741a09800a8fd309f058d7e540128f3a6c9e82e46ab77d57b839c8a7e8972877fcEpPBTGmddbkg8pjuG3FzAO3ussiiVuy9txR2noPcI=', '4dbe690c9965b1f857fac1e13cf26df2c52b72464b49797df03af3e8777afca035e93bc390ec5425cfba8f95a97013c95ffc407a40cdec54078ba1ce2e2af525A8RxmZJotYctDe+mKIqOAvZ/0JrIVzYRCgQt1hkwXik=', '0121-12-31', '231', '321', 'dsf', 'efe8ed922fb2c43f2fde79d552feda30ed9cd9e905609832513fd23d81f8f8dc34351c93efc658862e903abf4220f27f3e58997cbff64116c02e6a5211a8eed4cg/gQbqcNAourycTPsZgj94J7keMyihPyo1kLAsLbTs=', 'someemail@gmail.com', 'ahmet', '$2y$10$N/lei.fZz/6aWdOzrazK6ePjA', 'dfs', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');
INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (8, '39018d06cff5ff3bb4392ed55b2de3d2101c1f612034dd1d5957f65a426f7eec741a09800a8fd309f058d7e540128f3a6c9e82e46ab77d57b839c8a7e8972877fcEpPBTGmddbkg8pjuG3FzAO3ussiiVuy9txR2noPcI=', '4dbe690c9965b1f857fac1e13cf26df2c52b72464b49797df03af3e8777afca035e93bc390ec5425cfba8f95a97013c95ffc407a40cdec54078ba1ce2e2af525A8RxmZJotYctDe+mKIqOAvZ/0JrIVzYRCgQt1hkwXik=', '2019-07-16', 'dsf', 'dsf', '', 'efe8ed922fb2c43f2fde79d552feda30ed9cd9e905609832513fd23d81f8f8dc34351c93efc658862e903abf4220f27f3e58997cbff64116c02e6a5211a8eed4cg/gQbqcNAourycTPsZgj94J7keMyihPyo1kLAsLbTs=', 'someemail@gmail.com', 'username', '$2y$10$G/toi4HH3bq7k8cIbyhxOOAjx', 'dsa', '133125810d693d25bd06ef3f9c4002e72de233f8faab703dc49022cfe5a195dee1b8aba43435311403a7107a76a7d6d4f6b7d4bfd0edd7750b3e5eeca75afc58Xz2Cq5bsDfjlV4JnwyeZMKMlYouExA91Udn5PCpEuTQ=');


#
# TABLE STRUCTURE FOR: scan
#

DROP TABLE IF EXISTS `scan`;

CREATE TABLE `scan` (
  `scan_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(256) DEFAULT NULL,
  `scan_desc` text,
  `appointment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`scan_id`),
  KEY `fk_appointment_id` (`appointment_id`),
  CONSTRAINT `fk_appointment_id` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;

INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (5, '145ea45e25b7a87864b1256e6839f62a6b855e96acad7edf96cdf53a07dc3c7508a957fb03cb3fe0fec45cc9cf2780609b2042c5f6521ce1d38c808b66e8a461OL5L+tib/hfJMuPe3meD+tPBhCD/vtM5zvi+DmL8WJCx0o0tszkxjtyvLPMdU+64', 'sadfasdfasfasf', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (6, '145ea45e25b7a87864b1256e6839f62a6b855e96acad7edf96cdf53a07dc3c7508a957fb03cb3fe0fec45cc9cf2780609b2042c5f6521ce1d38c808b66e8a461OL5L+tib/hfJMuPe3meD+tPBhCD/vtM5zvi+DmL8WJCx0o0tszkxjtyvLPMdU+64', 'new description', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (7, '145ea45e25b7a87864b1256e6839f62a6b855e96acad7edf96cdf53a07dc3c7508a957fb03cb3fe0fec45cc9cf2780609b2042c5f6521ce1d38c808b66e8a461OL5L+tib/hfJMuPe3meD+tPBhCD/vtM5zvi+DmL8WJCx0o0tszkxjtyvLPMdU+64', 'tasks desc', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (8, '145ea45e25b7a87864b1256e6839f62a6b855e96acad7edf96cdf53a07dc3c7508a957fb03cb3fe0fec45cc9cf2780609b2042c5f6521ce1d38c808b66e8a461OL5L+tib/hfJMuPe3meD+tPBhCD/vtM5zvi+DmL8WJCx0o0tszkxjtyvLPMdU+64', 'flowers desc', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (9, '145ea45e25b7a87864b1256e6839f62a6b855e96acad7edf96cdf53a07dc3c7508a957fb03cb3fe0fec45cc9cf2780609b2042c5f6521ce1d38c808b66e8a461OL5L+tib/hfJMuPe3meD+tPBhCD/vtM5zvi+DmL8WJCx0o0tszkxjtyvLPMdU+64', 'fdsfadsfads', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (10, '9c465a55d741a4c349d98e08c65864209bc95790e93fce8ba556b72fb22cb5b09af491e7c9241bfd4ff14a8df09ef908c2cb7b9207c06be1dbf769aae31418eaISjFYBsWIfrGlTN0JuuKDh4Lu7lGo2oujjED1jWCxXw=', 'diagram', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (11, '9c465a55d741a4c349d98e08c65864209bc95790e93fce8ba556b72fb22cb5b09af491e7c9241bfd4ff14a8df09ef908c2cb7b9207c06be1dbf769aae31418eaISjFYBsWIfrGlTN0JuuKDh4Lu7lGo2oujjED1jWCxXw=', 'let\'s see', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (12, '9c465a55d741a4c349d98e08c65864209bc95790e93fce8ba556b72fb22cb5b09af491e7c9241bfd4ff14a8df09ef908c2cb7b9207c06be1dbf769aae31418eaISjFYBsWIfrGlTN0JuuKDh4Lu7lGo2oujjED1jWCxXw=', 'let\'s see', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (15, '9c465a55d741a4c349d98e08c65864209bc95790e93fce8ba556b72fb22cb5b09af491e7c9241bfd4ff14a8df09ef908c2cb7b9207c06be1dbf769aae31418eaISjFYBsWIfrGlTN0JuuKDh4Lu7lGo2oujjED1jWCxXw=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (16, '9c465a55d741a4c349d98e08c65864209bc95790e93fce8ba556b72fb22cb5b09af491e7c9241bfd4ff14a8df09ef908c2cb7b9207c06be1dbf769aae31418eaISjFYBsWIfrGlTN0JuuKDh4Lu7lGo2oujjED1jWCxXw=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (17, '9c465a55d741a4c349d98e08c65864209bc95790e93fce8ba556b72fb22cb5b09af491e7c9241bfd4ff14a8df09ef908c2cb7b9207c06be1dbf769aae31418eaISjFYBsWIfrGlTN0JuuKDh4Lu7lGo2oujjED1jWCxXw=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (18, '9c465a55d741a4c349d98e08c65864209bc95790e93fce8ba556b72fb22cb5b09af491e7c9241bfd4ff14a8df09ef908c2cb7b9207c06be1dbf769aae31418eaISjFYBsWIfrGlTN0JuuKDh4Lu7lGo2oujjED1jWCxXw=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (19, '9c465a55d741a4c349d98e08c65864209bc95790e93fce8ba556b72fb22cb5b09af491e7c9241bfd4ff14a8df09ef908c2cb7b9207c06be1dbf769aae31418eaISjFYBsWIfrGlTN0JuuKDh4Lu7lGo2oujjED1jWCxXw=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (20, '9c465a55d741a4c349d98e08c65864209bc95790e93fce8ba556b72fb22cb5b09af491e7c9241bfd4ff14a8df09ef908c2cb7b9207c06be1dbf769aae31418eaISjFYBsWIfrGlTN0JuuKDh4Lu7lGo2oujjED1jWCxXw=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (21, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (22, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (23, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (24, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (25, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (26, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (27, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (28, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (29, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (30, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (31, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (32, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (33, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (34, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (35, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (36, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (37, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (38, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (39, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (40, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (41, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (42, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (43, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (44, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (45, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (46, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (47, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (48, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (49, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (50, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (51, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (52, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (53, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (54, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (55, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (56, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (57, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (58, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (59, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (60, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'flowersb ones', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (61, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'dsafadsf', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (62, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'dfas', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (63, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'flower', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (64, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'dfsaf', 3);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (65, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'lk;sjfadslkjfdsa', 3);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (66, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', '', 10);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (67, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', '', 10);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (68, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'fdsafas', 10);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (69, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'some desc', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (70, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'skdljasd', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (71, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 's', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (72, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', '', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (73, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'dsa', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (74, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'some flowers here', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (75, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', '', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (76, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'd', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (77, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'd', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (78, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'd', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (79, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (80, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (81, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (82, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (83, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (84, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (85, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (86, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (87, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (88, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (89, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (90, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'first', 12);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (91, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'second', 12);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (92, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'third', 12);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (93, 'e33fa5cea395f23a922a68572863cea35ef90f01e486c9c4962b9f13c1d4c3001f06be13464a4350e4c1e0933e1238bc25d765c4b15b05c5da691881c9edc3a0OeRwdj/ZO7d1xfrWAkVTCiL0Dd6/RLQPCeF9/oDPgV8=', 'tasks first', 14);


