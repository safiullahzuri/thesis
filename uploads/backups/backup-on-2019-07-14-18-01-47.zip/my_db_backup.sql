#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `firstname` varchar(32) DEFAULT NULL,
  `lastname` varchar(32) DEFAULT NULL,
  `image` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `admin` (`admin_id`, `username`, `password`, `firstname`, `lastname`, `image`) VALUES (2, 'admin', 'admin', 'Safiullah', 'zuri', 'flowers5.jpg');


#
# TABLE STRUCTURE FOR: appointment
#

DROP TABLE IF EXISTS `appointment`;

CREATE TABLE `appointment` (
  `app_id` int(11) NOT NULL AUTO_INCREMENT,
  `sdate` date NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `description` text,
  `ptime` time NOT NULL,
  `display` varchar(10) NOT NULL,
  PRIMARY KEY (`app_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (1, '2121-12-13', 1, 1, 'undefined', '00:12:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (2, '2121-12-13', 1, 1, 'undefined', '00:12:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (3, '0000-00-00', 3, 1, 'undefined', '00:00:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (4, '0000-00-00', 1, 1, '', '00:00:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (5, '0000-00-00', 1, 1, 'dfadsf', '00:00:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (9, '2019-07-16', 3, 1, '', '00:00:00', 'yes');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (10, '2019-07-02', 1, 1, 'let\'s see', '12:32:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (11, '2212-12-21', 4, 1, 'sfsadfa12', '00:12:00', 'yes');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (12, '0001-07-25', 1, 1, 'my appointment', '00:12:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (13, '1321-02-13', 1, 1, 'some mess', '00:13:00', 'no');
INSERT INTO `appointment` (`app_id`, `sdate`, `doctor_id`, `patient_id`, `description`, `ptime`, `display`) VALUES (14, '0031-02-06', 1, 1, 'some appointment', '02:11:00', 'no');


#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS `backup`;

CREATE TABLE `backup` (
  `backup_id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_date` date NOT NULL,
  `backup_address` varchar(128) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_type` varchar(64) NOT NULL,
  PRIMARY KEY (`backup_id`),
  CONSTRAINT `backup_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `doctor` (`doctor_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: diagnosis
#

DROP TABLE IF EXISTS `diagnosis`;

CREATE TABLE `diagnosis` (
  `diagnosis_id` int(11) NOT NULL AUTO_INCREMENT,
  `diagnosis_file` varchar(256) DEFAULT NULL,
  `appointment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`diagnosis_id`),
  KEY `appointment_id` (`appointment_id`),
  CONSTRAINT `diagnosis_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (4, '2019-07-08-07-07-00diagnosisnew.txt', 4);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (11, '2019-07-12-09-11-26diagnosis.txt', 5);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (13, '2019-07-09-01-43-19diagnosis.txt', 2);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (14, '2019-07-09-01-48-37diagnosis.txt', 1);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (15, '2019-07-09-06-23-42diagnosis.txt', 3);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (16, '2019-07-11-11-32-51diagnosis.txt', 10);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (17, '2019-07-11-11-39-02diagnosis.txt', 10);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (18, '2019-07-11-11-39-18diagnosis.txt', 10);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (19, '2019-07-12-04-22-32diagnosis.txt', 1);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (20, '2019-07-12-04-23-23diagnosis.txt', 1);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (21, '2019-07-12-04-30-04diagnosis.txt', 1);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (22, '2019-07-12-08-12-51diagnosis.txt', 5);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (23, '2019-07-12-08-59-58diagnosis.txt', 5);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (24, '2019-07-13-07-03-20diagnosis.txt', 13);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (25, '2019-07-13-08-48-20diagnosis.txt', 12);
INSERT INTO `diagnosis` (`diagnosis_id`, `diagnosis_file`, `appointment_id`) VALUES (26, '2019-07-13-09-34-22diagnosis.txt', 14);


#
# TABLE STRUCTURE FOR: doctor
#

DROP TABLE IF EXISTS `doctor`;

CREATE TABLE `doctor` (
  `doctor_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(32) DEFAULT NULL,
  `lastname` varchar(32) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `city` varchar(32) DEFAULT NULL,
  `street` varchar(32) DEFAULT NULL,
  `postCode` varchar(32) DEFAULT NULL,
  `email` varchar(32) DEFAULT NULL,
  `phoneNo` varchar(32) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `image` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `doctor` (`doctor_id`, `firstname`, `lastname`, `dob`, `city`, `street`, `postCode`, `email`, `phoneNo`, `username`, `password`, `image`) VALUES (1, 'doctor', 'doctor', '2019-07-02', 'herat', 'herat', 'herat', 'heratedited@gm.com', 'herat', 'hetrat', 'herat', 'tasks.jpg');
INSERT INTO `doctor` (`doctor_id`, `firstname`, `lastname`, `dob`, `city`, `street`, `postCode`, `email`, `phoneNo`, `username`, `password`, `image`) VALUES (3, 'sdf', 'asf', '0000-00-00', 'dsaf', 'dsafa', 'dsafa', 's@g.com', 'sdfa', 'sd', 'sd', 'flowers3.jpg');
INSERT INTO `doctor` (`doctor_id`, `firstname`, `lastname`, `dob`, `city`, `street`, `postCode`, `email`, `phoneNo`, `username`, `password`, `image`) VALUES (4, 's', 'Zuri', '1122-02-12', 'fdas', 'dasf', 'dsfsad', 's@g.com', 'dsfadfa', 'sfs', 'dfjsl', 'pexels-photo-658687.jpeg');


#
# TABLE STRUCTURE FOR: patient
#

DROP TABLE IF EXISTS `patient`;

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(32) DEFAULT NULL,
  `lastname` varchar(32) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `job` varchar(32) DEFAULT NULL,
  `city` varchar(32) DEFAULT NULL,
  `street` varchar(32) DEFAULT NULL,
  `postCode` varchar(16) DEFAULT NULL,
  `email` varchar(32) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `phoneNo` varchar(32) DEFAULT NULL,
  `image` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (1, 'safiullah edited', 'zuri ', '2019-07-15', 'dfa', 'lsdajfalj', 'lkdjaslkfj', 'lkjdsaf', 's@g.com', 'safi', 'password', 'dsljfsalj', 'flowers.jpg');
INSERT INTO `patient` (`patient_id`, `firstname`, `lastname`, `dob`, `job`, `city`, `street`, `postCode`, `email`, `username`, `password`, `phoneNo`, `image`) VALUES (2, 'sfj', 'lkjdal', '2222-01-29', 'lkfdjal', 'dkfjsl', 'lkdjfal', 'lkjfsk', 'a@g.com', 'dfasfd', 'sdjf', '231321', 'File_00022.jpg');


#
# TABLE STRUCTURE FOR: scan
#

DROP TABLE IF EXISTS `scan`;

CREATE TABLE `scan` (
  `scan_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(256) DEFAULT NULL,
  `scan_desc` text,
  `appointment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`scan_id`),
  KEY `fk_appointment_id` (`appointment_id`),
  CONSTRAINT `fk_appointment_id` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;

INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (5, 'flowers.jpg', 'sadfasdfasfasf', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (6, 'tasks.jpg', 'new description', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (7, 'tasks.jpg', 'tasks desc', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (8, 'flowers.jpg', 'flowers desc', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (9, 'flowers.jpg', 'fdsfadsfads', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (10, 'erdplus-diagram.png', 'diagram', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (11, 'erdplus-diagram.png', 'let\'s see', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (12, 'erdplus-diagram.png', 'let\'s see', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (15, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (16, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (17, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (18, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (19, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (20, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (21, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (22, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (23, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (24, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (25, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (26, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (27, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (28, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (29, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (30, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (31, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (32, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (33, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (34, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (35, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (36, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (37, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (38, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (39, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (40, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (41, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (42, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (43, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (44, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (45, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (46, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (47, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (48, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (49, 'erdplus-diagram.png', 'bakalim', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (50, 'tasks.jpg', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (51, 'tasks.jpg', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (52, 'tasks.jpg', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (53, 'tasks.jpg', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (54, 'tasks.jpg', 'dsfasdfas', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (55, 'pexels-photo-658687.jpeg', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (56, 'pexels-photo-658687.jpeg', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (57, 'pexels-photo-658687.jpeg', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (58, 'pexels-photo-658687.jpeg', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (59, 'pexels-photo-658687.jpeg', 'pexels fala nf ilan', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (60, 'flowers.jpg', 'flowersb ones', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (61, 'tasks.jpg', 'dsafadsf', 4);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (62, 'tasks.jpg', 'dfas', 2);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (63, 'flowers.jpg', 'flower', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (64, 'pexels-photo-658687.jpeg', 'dfsaf', 3);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (65, 'tasks.jpg', 'lk;sjfadslkjfdsa', 3);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (66, 'flowers.jpg', '', 10);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (67, 'File_00022.jpg', '', 10);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (68, 'tasks.jpg', 'fdsafas', 10);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (69, 'pexels-photo-658687.jpeg', 'some desc', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (70, 'tasks.jpg', 'skdljasd', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (71, 'pexels-photo-658687.jpeg', 's', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (72, 'tasks.jpg', '', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (73, 'pexels-photo-658687.jpeg', 'dsa', 1);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (74, 'flowers.jpg', 'some flowers here', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (75, 'tasks.jpg', '', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (76, 'flowers.jpg', 'd', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (77, 'flowers.jpg', 'd', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (78, 'tasks.jpg', 'd', 5);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (79, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (80, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (81, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (82, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (83, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (84, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (85, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (86, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (87, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (88, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (89, 'tasks.jpg', 'let\'s see the diagnosis', 13);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (90, 'File_00022.jpg', 'first', 12);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (91, 'flowers.jpg', 'second', 12);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (92, 'pexels-photo-658687.jpeg', 'third', 12);
INSERT INTO `scan` (`scan_id`, `file_name`, `scan_desc`, `appointment_id`) VALUES (93, 'tasks.jpg', 'tasks first', 14);


